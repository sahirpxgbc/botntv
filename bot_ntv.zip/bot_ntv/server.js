/*const Discord = require("discord.js");
const client = new Discord.Client();

const config = require("./config.json")
const fs = require("fs")

client.commandos = new Discord.Collection()


//////////ENTRADA: (ESTADO DEL BOT)////////////

client.on("ready", () => {
  console.log("Bot LISTO!");

  client.user.setPresence( {
      activity: {
          name: "Usa *help para ver todos mis comandos.",
          type: "PLAYING"
      },
      status: "online"
   });

});*/

/*client.login(config.token);
 
let prefix = config.prefix;
client.on("message", (message) => {


    if(message.author.bot) return;
    if (!message.content.startsWith(prefix)) return;
      
        const args = message.content.slice(prefix.length).trim().split(/ +/g);
        const command = args.shift().toLowerCase(); 
        
    if(command === "help"){
        message.channel.send("```NeshyTV Mod en fase de desarrollo. Estate atento a los anuncios de los moderadores para mi proxÍmo lanzamiento oficial.```")      
     }
});*/

/*client.on("message", message =>{
    if(message.author.bot) return;
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const command = args.shift().toLowerCase(); 
   
  if(command === 'prueba'){
   const embed = new Discord.MessageEmbed()
      .setTitle('Comando de mensaje embed')
      .setColor(0xEAB607)
      .setDescription('Command embed. Embed basico, para pruebas y modificaciones. ')
      .addField('Name Server', message.guild.name, true)
      .addField('Users', message.guild.memberCount, true)
      // .setAuthor(client.user.username, client.user.avatarURL())
      .setThumbnail('https://img.huffingtonpost.es/uploads/2022/12/07/6390d93f25f77.gif')
      .setImage('https://i.gifer.com/PlI.gif')
      .setFooter('Solicitado por: '+message.member.displayName, message.author.avatarURL())
      .setTimestamp()
      //.setURL('https://www.youtube.com/channel/UCa6KCEgU2DaXM0U5QCNcTeA');

      //NOMBRE DEL BOT: client.user.username
      //AVALAR DE BOT: client.user.avatarURL()
      //NOMBRE DE USUARIO: message.member.displayName
      //AVATAR DE USUARIO: message.author.avatarURL()
    message.channel.send(embed);

  }
  });*/

 /* client.on("message", message =>{
    if(message.author.bot) return;
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const command = args.shift().toLowerCase(); 
   
  if(command === 'ntv-info'){
   const channelID = '1043968042687811655';
   const channelMention = `<#${channelID}>`;
   const embed = new Discord.MessageEmbed()


      .setTitle('Sobre Neshy Television...')
      .setColor(0xEAB607)
      .setDescription('En NeshyTV tenemos una enorme pasión por lo que hacemos, estamos dispuestos a '
      + 'aceptar el cambio. Tenemos la misión de ofrecer contenido y servicio de gran calidad. Nuestra gran'
      + ' vision es ser la organización líder en los medios de comunicación de San Andreas.\n\n'
      + 'Por ultimo pero no menos importante, nuestra mision es satisfacer las necesidades' 
      + 'de información a nuestra audiencia, cumpliendo los estándares de calidad, creatividad y' 
      + 'responsabilidad social. Sabemos que nuestra existencia es necesaria, por eso estamos comprometidos con nuestro público.'
      + 'Para mas informacion sobre NeshyTV, consulta el manual ubicado en ' + channelMention)
      .setAuthor(client.user.username, client.user.avatarURL())
      .setImage('https://github.com/jtavera17/img-for-discord091523/blob/main/barra1.gif?raw=true')
      //.setImage('https://github.com/jtavera17/img-for-discord091523/blob/main/NESHYTV%20GIF1.gif?raw=true')
      .setFooter('Solicitado por: '+message.member.displayName, message.author.avatarURL())
      .setTimestamp()
      //.setURL('https://www.youtube.com/channel/UCa6KCEgU2DaXM0U5QCNcTeA');

      //NOMBRE DEL BOT: client.user.username
      //AVALAR DE BOT: client.user.avatarURL()
      //NOMBRE DE USUARIO: message.member.displayName
      //AVATAR DE USUARIO: message.author.avatarURL()
    message.channel.send(embed);

  }
  });*/

 
/*    const intervalo = 7200000; // En este ejemplo, se enviará cada hora (3600000 ms) 

    const canalID = '1151698285254410390'; 
    const channelID = '1049315959900475473';
    const channelMention = `<#${channelID}>`;
  
   setInterval(() => {
      const embed = new Discord.MessageEmbed()
        .setTitle('Consejo...')
        .setColor('#FF0000')
        .setDescription('Al estar jugando IC, recuerda anunciar tu servicio por el canal: '+ channelMention
        + ' así evitas llamados de atención, por parte de la Cúpula de NeshyTelevisión');
  
      // Busca el canal por su ID
      const canal = client.channels.cache.get(canalID);
  
      if (canal) {
        canal.send(embed);
      } else {
        console.error('No se encontró el canal con la ID proporcionada.');
      }
    }, intervalo);*/
    


 /*   // Define los IDs de los roles permitidos
const rolesPermitidos = ['1152395322404905100', '1152395478181359637', '1152395565775200336', '1152037857259696200'];

client.on('message', async message => {
  if (message.author.bot) return;
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'expulsar') {
    if (
      message.member.roles.cache.some(role =>
        rolesPermitidos.includes(role.id)
      )
    ) {
      const userToKick = message.mentions.members.first();
      if (!userToKick) {
        return message.reply('Debes mencionar al usuario que deseas expulsar.');
      }

      const reason = args.slice(1).join(' ') || 'Sin razón especificada';

      try {
        await userToKick.kick();

        const embed = new Discord.MessageEmbed()
          .setColor('#FF0000')
          .setTitle('Usuario Expulsado')
          .setDescription(`El usuario ${userToKick} ha sido expulsado del servidor.`)
          .addField('Razón:', reason)
          .setFooter(`Expulsado por: ${message.author.tag}`, message.author.avatarURL())
          .setTimestamp();

        message.channel.send(embed);
      } catch (error) {
        console.error(error);
        message.reply('Hubo un error al intentar expulsar al usuario.');
      }
    } else {
      message.reply('No tienes los permisos para usar este comando.');
    }
  }
});*/

 /*client.login(config.token);*/
