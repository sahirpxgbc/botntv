const Discord = require('discord.js');

module.exports = {
  name: 'creditos',
  description: 'Muestra los usuarios que participaron en el bot',
  execute(message, args) {
    const member1 = message.guild.members.cache.get('1070424464464040087'); 
    const member2 = message.guild.members.cache.get('934989816095981678'); 
    const member3 = message.guild.members.cache.get('782514583251583036'); 

    const embed = new Discord.MessageEmbed()
      .setTitle('`🔰` Creditos de la creación de Neshy Televisión Mod `🔰`')
      .setColor('#EB6000')
      .setDescription('`❓` Personas que ayudaron en mi programación:\n\n'
        +  '`📖`' + `- ${member1} | sahir_px -` + ' `🖥️` **(Programador)**\n\n'
        +  '`📖`' + `- ${member2} | Gerardo#9422 -` + ' `🤖` **(Tester del Bot)**\n\n'
        +  '`📖`' + `- ${member3} | RobertRial8841#9422 -` + ' `🤖` **(Tester del Bot)**\n\n'
        + ' `✅` *Versión del bot: V3.5.5*')
      .setFooter('Solicitado por: ' + message.member.displayName, message.author.avatarURL())
      .setTimestamp();

    message.channel.send(embed);
  },
};