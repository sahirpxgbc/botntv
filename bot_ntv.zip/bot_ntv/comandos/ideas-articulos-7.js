const Discord = require('discord.js');
// IDs de los roles permitidos
const rolesPermitidos = ['1151698401457602580', '1041737341519282256', '1091895225783435345']; // Reemplaza con los IDs de los roles permitidos

module.exports = {
  name: 'ideas-articulos-7',
  description: 'Envia ideas para NTV.',
  execute(message, args) {
    const tieneRolPermitido = message.member.roles.cache.some(role => rolesPermitidos.includes(role.id));
    if (!tieneRolPermitido) {
      return message.reply('No tienes permiso para usar este comando.');
    }
    
    const embed = new Discord.MessageEmbed()
    .setTitle('`🕜` Comando en espera... `🕜`')
    .setColor(0xEAB607)
    .setDescription('El comando que estas utilizando esta en desarrollo.'
    + ' Estate atento a la proxíma actualizacion para más ideas de articulos...')
    .setFooter('Solicitado por: '+message.member.displayName, message.author.avatarURL())
    .setTimestamp()
    message.channel.send(embed);
  },
};