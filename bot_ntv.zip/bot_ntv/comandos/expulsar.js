const Discord = require('discord.js');
const rolesPermitidos = ['1041737341519282256', '1041737829639794748', '1041737807632273469', '1151698401457602580', '1152395565775200336', '1152395478181359637', '1152395322404905100'];

module.exports = {
  name: 'expulsar',
  description: 'Expulsa a un usuario del servidor',
  execute(message, args) {
    if (
      message.member.roles.cache.some(role =>
        rolesPermitidos.includes(role.id)
      )
    ) {
      const userToKick = message.mentions.members.first();
      if (!userToKick) {
        return message.reply('`Debes mencionar al usuario que deseas expulsar.`');
      }

      const reason = args.slice(1).join(' ') || 'Sin razón especificada';

      try {
        userToKick.kick().then(() => {
          const embed = new Discord.MessageEmbed()
            .setColor('#D60000')
            .setTitle('`⚠️` Usuario Expulsado `⚠️`')
            .setDescription('`📢`' + `El usuario ${userToKick} ha sido expulsado del servidor.`)
            .addField('`✏️` Razón:', reason)
            .setFooter('`👤`' + `Expulsado por: ${message.author.tag}`, message.author.avatarURL())
            .setTimestamp();

          message.channel.send(embed);
        });
      } catch (error) {
        console.error(error);
        message.reply('`Hubo un error al intentar expulsar al usuario.`');
      }
    } else {
      message.reply('`No tienes los permisos para usar este comando.`');
    }
  },
};