const Discord = require('discord.js');
// IDs de los roles permitidos
const rolesPermitidos = ['1151698401457602580', '1041737341519282256', '1091895225783435345']; // Reemplaza con los IDs de los roles permitidos

module.exports = {
  name: 'prefix',
  description: 'Muestra el prefijo del bot actual.',
  execute(message, args) {
    const tieneRolPermitido = message.member.roles.cache.some(role => rolesPermitidos.includes(role.id));
    if (!tieneRolPermitido) {
      return message.reply('No tienes permiso para usar este comando.');
    }
    
    const embed = new Discord.MessageEmbed()
    .setTitle('`🏷️` Prefijo actual del Bot...')
    .setColor('#00FAF6')
    .setDescription('`🔰` Mi prefix actual para ejecutar comandos es: `/[texto]`. Si quieres usar alguno'
    + ' comando, recuerda usar: `/ayuda`')
    .setFooter('Solicitado por: '+message.member.displayName, message.author.avatarURL())
    .setTimestamp()
    message.channel.send(embed);
  },
};