const https = require('https');
const Discord = require('discord.js');

module.exports = {
  name: 'tiktokstats',
  description: 'Muestra las estadísticas de un video de TikTok.',
  async execute(message, args) {
    const videoURL = args[0];

    if (!videoURL) {
      return message.reply('Por favor, proporcione una URL de video de TikTok válida.');
    }

    try {
      const response = await fetchVideoStats(videoURL);
      const data = JSON.parse(response);

      if (data.statusCode === 0) {
        const embed = new Discord.MessageEmbed()
          .setColor('#0099ff')
          .setTitle('Estadísticas de vídeos de TikTok')
          .setURL(videoURL)
          .setDescription(data.body.sections[0].contents[0].desc)
          .setThumbnail(data.body.itemInfos.video.cover)
          .addFields(
            { name: 'Vistas', value: data.body.itemInfos.video.playCount, inline: true },
            { name: 'Likes', value: data.body.itemInfos.video.diggCount, inline: true },
            { name: 'Comentarios', value: data.body.itemInfos.video.commentCount, inline: true },
            { name: 'Compartidos', value: data.body.itemInfos.video.shareCount, inline: true },
          )
          .setTimestamp();

        message.channel.send(embed);
      } else {
        message.reply('No se pueden recuperar las estadísticas de vídeo de TikTok. Inténtalo de nuevo.');
      }
    } catch (error) {
      console.error(error);
      message.reply('No se pueden recuperar las estadísticas de vídeo de TikTok. Inténtalo de nuevo.');
    }
  },
};

async function fetchVideoStats(videoURL) {
  return new Promise((resolve, reject) => {
    https.get(`https://www.tiktok.com/node/share/video/${videoURL.split('/').pop()}?shareUid=`, (response) => {
      let data = '';

      response.on('data', (chunk) => {
        data += chunk;
      });

      response.on('end', () => {
        resolve(data);
      });
    }).on('error', (error) => {
      reject(error);
    });
  });
}
