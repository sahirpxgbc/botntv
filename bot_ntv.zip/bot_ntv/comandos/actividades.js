const Discord = require('discord.js');

// IDs de los roles permitidos
const rolesPermitidos = ['1151698401457602580', '1041737341519282256', '1091895225783435345']; // Reemplaza con los IDs de los roles permitidos

module.exports = {
  name: 'actividades',
  description: 'Envia las actividades semanales para los usuarios.',
  execute(message, args) {

    const tieneRolPermitido = message.member.roles.cache.some(role => rolesPermitidos.includes(role.id));
    if (!tieneRolPermitido) {
      return message.reply('No tienes permiso para usar este comando.');
    }

    const embed = new Discord.MessageEmbed()
    .setTitle('`🧭` Actividades semanales `🧭`')
    .setColor(0xEAB607)
    .setDescription('***Estas son las actividades semanales. Si deseas completarlas y ganar premios extras'
    + ' sigue cada uno de los pasos aqui dichos.***\n\n'
    + ' * `📸` Tomate una foto con un SAPD.\n\n'
    + ' * `📸` Toma 5 fotografias a 5 vehículos de trabajos diferentes.`\n\n'
    + ' * `📸` Has una transmisión de 30m o más. Tema: Delincuencia.\n\n'
    + ' * `📸` Has de chofer para un miembro/rango superior al tuyo.\n\n'
    + ' * `📸` Regala una sesión de fotos a quien desees.\n\n'
    + ' `💼` Si no sabes donde subir tus actividades semanales mira: `/ayuda-actividades`'
    + ' ***`💡` Estas actividades se reiniciarán el 11/02/24 `💡`***')
    .setFooter('Solicitado por: '+message.member.displayName, message.author.avatarURL())
    .setTimestamp()
    message.channel.send(embed);
  },
};




/*const Discord = require('discord.js');
// IDs de los roles permitidos
const rolesPermitidos = ['1151698401457602580', '1041737341519282256', '1091895225783435345']; // Reemplaza con los IDs de los roles permitidos

 module.exports = {
  name: 'actividades',
  description: 'actividades.',
  execute(message, args) {
    const tieneRolPermitido = message.member.roles.cache.some(role => rolesPermitidos.includes(role.id));
    if (!tieneRolPermitido) {
      return message.reply('No tienes permiso para usar este comando.');
    }
    
    const embed = new Discord.MessageEmbed()
    .setTitle('`🕜` Comando en espera... `🕜`')
    .setColor(0xEAB607)
    .setDescription('El comando que estas utilizando esta en desarrollo.'
    + ' Estate atento a la proxíma actualizacion para visualizar las nuevas actividades...')
    .setFooter('Solicitado por: '+message.member.displayName, message.author.avatarURL())
    .setTimestamp()
    message.channel.send(embed);
  },
};*/


